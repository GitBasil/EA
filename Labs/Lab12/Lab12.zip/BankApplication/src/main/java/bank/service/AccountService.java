package bank.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bank.DTO.*;
import bank.DTO.adapters.*;
import bank.domain.Account;
import bank.domain.Customer;
import bank.domain.TraceLog;
import bank.jms.IJMSSender;
import bank.logging.ILogger;
import bank.repositories.*;

@Service
@Transactional
public class AccountService implements IAccountService {
	@Autowired
	private ICurrencyConverter currencyConverter;
	@Autowired
	private IJMSSender jmsSender;
	@Autowired
	private ILogger logger;
	@Autowired
	AccountRepository accountRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	TraceLogRepository traceLogRepository;

	@Autowired
	private ApplicationEventPublisher publisher;
	
	public AccountDTO createAccount(long accountNumber, String customerName) {
		Customer customer = new Customer(new java.util.Random().nextInt(100), customerName);
		customerRepository.save(customer);
		Account account = new Account(accountNumber);
		account.setCustomer(customer);
		accountRepository.save(account);
		logger.log("createAccount with parameters accountNumber= "+accountNumber+" , customerName= "+customerName);

		return AccountAdapter.getAccountDTOFromAccount(account);
	}

	

	public AccountDTO getAccount(long accountNumber) {
		Account account = accountRepository.findById(accountNumber).get();
		
		return AccountAdapter.getAccountDTOFromAccount(account);
	}

	public List<AccountDTO> getAllAccounts() {
		List<Account> accounts = accountRepository.findAll();
		List<AccountDTO> accountDTOs = accounts.stream().
														map(m -> AccountAdapter.getAccountDTOFromAccount(m))
														.toList();
		return accountDTOs;
	}

	public void deposit(long accountNumber, double amount) {
		Account account = accountRepository.findById(accountNumber).get();
		account.deposit(amount);
		accountRepository.save(account);
		logger.log("deposit with parameters accountNumber= "+accountNumber+" , amount= "+amount);
		if (amount > 10000){
			jmsSender.sendJMSMessage("Deposit of $ "+amount+" to account with accountNumber= "+accountNumber);
		}

		publisher.publishEvent(new TraceLog(LocalDateTime.now(), accountNumber, "deposit", amount));
	}

	public void withdraw(long accountNumber, double amount) {
		Account account = accountRepository.findById(accountNumber).get();
		account.withdraw(amount);
		accountRepository.save(account);
		logger.log("withdraw with parameters accountNumber= "+accountNumber+" , amount= "+amount);

		publisher.publishEvent(new TraceLog(LocalDateTime.now(), accountNumber, "withdraw", amount));
	}

	public void depositEuros(long accountNumber, double amount) {
		Account account = accountRepository.findById(accountNumber).get();
		double amountDollars = currencyConverter.euroToDollars(amount);
		account.deposit(amountDollars);
		accountRepository.save(account);
		logger.log("depositEuros with parameters accountNumber= "+accountNumber+" , amount= "+amount);
		if (amountDollars > 10000){
			jmsSender.sendJMSMessage("Deposit of $ "+amount+" to account with accountNumber= "+accountNumber);
		}

		publisher.publishEvent(new TraceLog(LocalDateTime.now(), accountNumber, "depositEuros", amount));
	}

	public void withdrawEuros(long accountNumber, double amount) {
		Account account = accountRepository.findById(accountNumber).get();
		double amountDollars = currencyConverter.euroToDollars(amount);
		account.withdraw(amountDollars);
		accountRepository.save(account);
		logger.log("withdrawEuros with parameters accountNumber= "+accountNumber+" , amount= "+amount);

		publisher.publishEvent(new TraceLog(LocalDateTime.now(), accountNumber, "withdrawEuros", amount));
	}

	public void transferFunds(long fromAccountNumber, long toAccountNumber, double amount, String description) {
		Account fromAccount = accountRepository.findById(fromAccountNumber).get();
		Account toAccount = accountRepository.findById(toAccountNumber).get();
		fromAccount.transferFunds(toAccount, amount, description);
		accountRepository.save(fromAccount);
		accountRepository.save(toAccount);
		logger.log("transferFunds with parameters fromAccountNumber= "+fromAccountNumber+" , toAccountNumber= "+toAccountNumber+" , amount= "+amount+" , description= "+description);
		if (amount > 10000){
			jmsSender.sendJMSMessage("TransferFunds of $ "+amount+" from account with accountNumber= "+fromAccount+" to account with accountNumber= "+toAccount);
		}

		publisher.publishEvent(new TraceLog(LocalDateTime.now(), fromAccount.getAccountnumber(), "transferFunds", amount));
	}
}
