package bank.DTO;

public record CustomerDTO(
    long id, 
    String name
) {}