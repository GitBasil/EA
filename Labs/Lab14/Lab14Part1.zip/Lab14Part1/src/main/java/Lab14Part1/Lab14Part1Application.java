package Lab14Part1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab14Part1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab14Part1Application.class, args);
	}

}
